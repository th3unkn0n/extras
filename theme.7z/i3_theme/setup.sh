#!/bin/bash

# switch to mirror
if [[ $1 == f ]]; then
sudo apt install apt-transport-https -y
echo "deb https://mirror-1.truenetwork.ru/kali kali-rolling main contrib non-free" \
| sudo tee /etc/apt/sources.list
sudo apt -y update
fi

# install packages
sudo apt -y install \
i3-gaps polybar blueman network-manager-gnome xcompmgr lxappearance feh \
rxvt-unicode xinput xserver-xorg-core x11-xserver-utils x11-utils xinit \
psmisc fonts-firacode fonts-quicksand

# copy configs
echo "exec i3" > $HOME/.xinitrc
cp .xresources $HOME
rm -rf $HOME/.config/i3 $HOME/.config/polybar
cp -r i3 $HOME/.config
cp -r polybar $HOME/.config
cp wp.jpg $HOME/.config

# check if .local/share/fonts/ exists
fontdir="$HOME/.local/share/fonts/"
if [[ -d $fontdir ]]; then :
else mkdir -p $fontdir
fi

# copy fonts and update font cache
cp fonts/materialdesignicons.ttf $fontdir
cp fonts/fontawesome-webfont.ttf $fontdir
cp -r fonts/SourceCodePro/ $fontdir
fc-cache -fv
