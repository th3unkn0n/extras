#!/bin/bash
# install required packages
apt install -y \
i3-gaps polybar blueman network-manager-gnome xcompmgr lxappearance feh \
rxvt-unicode xinput xserver-xorg-core x11-xserver-utils x11-utils xinit \
psmisc fonts-firacode fonts-quicksand

if [[ $1 == f ]]; then
apt install -y apt-transport-https
echo "deb https://mirror-1.truenetwork.ru/kali kali-rolling main contrib non-free" >\
/etc/apt/sources.list
apt update -y
fi

cp .xresources $HOME
rm -rf $HOME/.config/i3 $HOME/.config/polybar
cp -r i3 $HOME/.config
cp -r polybar $HOME/.config
cp wp.jpg $HOME/.config

# copy fonts and update font cache
fontdir="$HOME/.local/share/fonts/"
cp fonts/materialdesignicons.ttf $fontdir
cp fonts/fontawesome-webfont.ttf $fontdir
cp -r fonts/SourceCodePro/ $fontdir
fc-cache -fv
