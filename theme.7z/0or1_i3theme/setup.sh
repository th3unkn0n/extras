#!/bin/bash

if [[ "$EUID" -ne 0 ]]; then
	echo "[!] please run as root"
	exit
fi

# install required packages
apt install -y \
i3-gaps polybar blueman network-manager-gnome xcompmgr lxappearance feh\
rxvt-unicode xinput xserver-xorg-core x11-xserver-utils x11-utils xinit

if [[ $1 == f ]]; then
apt install -y apt-transport-https
echo "deb https://mirror-1.truenetwork.ru/kali kali-rolling main contrib non-free" >\
/etc/apt/sources.list
apt update -y
fi

cp .xresources $HOME

# check if config dir exists
if [[ -d "$HOME/.config" ]]; then
	echo "[+] found .config/ dir"
else cd $HOME && mkdir .config
fi

# copy fonts and update font cache
cp fonts/materialdesignicons.ttf /usr/share/fonts/truetype/
cp -r fonts/quicksand/ /usr/share/fonts/truetype/
cp -r fonts/SourceCodePro/ /usr/share/fonts/opentype/
fc-cache -fv
